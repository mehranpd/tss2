## Windows 11 RDP

**Here this tutorial using Azure Cloud Shell to create Virtual Machine on Microsoft Learn Sandbox.** <br><br>
***😎 Its Four Hours RDP Completely Free.***

## NEW VERSION RELEASE (W2022/W10/W11): 

- *Open This : https://docs.microsoft.com/vi-vn/learn/modules/monitor-azure-vm-using-diagnostic-data/3-exercise-create-virtual-machine?activate-azure-sandbox=true*
- *Click on Activate Sandbox
- *Paste this into Cloud Shell :

-   ```console  

    curl -skLO is.gd/azurewinvmplus ; chmod +x azurewinvmplus ; ./azurewinvmplus
    
    ```

![image](https://user-images.githubusercontent.com/58414694/161441694-583e8568-e98e-4e99-9219-0bd7a4c0f335.png)


### Using Method (W11-ONLY):


- *Open This : https://docs.microsoft.com/vi-vn/learn/modules/monitor-azure-vm-using-diagnostic-data/3-exercise-create-virtual-machine?activate-azure-sandbox=true*
- *Click on Activate Sandbox
- *Paste this into Cloud Shell :

-  ```console  
 
    curl -skLO is.gd/azurewin11vm ; chmod +x azurewin11vm ; ./azurewin11vm
    
    ```
- *Enjoy!!*



*VM Location: Random

*Username : azureuser

*Password: WindowsPassword@001


![image](https://user-images.githubusercontent.com/58414694/148490063-3657aeb5-541f-4e27-88a2-735ad990df0e.png)

- *Wait for it to setup the windows 11 machine*

- *After its done it will give you  the ip address of the rdp/vps *

- *open remote desktop client on windows type the ip and use the credentials provided*


### WARN
```
THIS IS ONLY FOR EDUCATIONAL PURPOSES

DON'T USE FOR MINING OR ILLEGAL USE
```
---

### OPTIONAL:

2H: https://docs.microsoft.com/vi-vn/learn/modules/create-linux-virtual-machine-in-azure/6-exercise-connect-to-a-linux-vm-using-ssh?activate-azure-sandbox=true

1H: https://docs.microsoft.com/vi-vn/learn/modules/build-a-web-app-with-mean-on-a-linux-vm/3-create-a-vm?activate-azure-sandbox=true

*FAQ: Script stuck at checking...? Restart Cloud Shell then Re-run script or activate new sandbox using OPTIONAL link above.*

#### Main Repository : https://github.com/kmille36/Windows-11-VPS
